const superagent = require('superagent');

const Similar = {

  getSimilars: async ({ query }) => {
    try {
      const res = await superagent
        .post("https://9fmnq42u71.execute-api.eu-west-1.amazonaws.com/default/tastedive")
        .send({
          query,
      });
      return res.body
    } catch (err) {
      return err
    }
  },

};

exports.handler = async function handler(event) {
  if (!event.query) return []
  return  Similar.getSimilars(event)
};

(async function () {

  const r = await Similar.getSimilars({ query: "metallica" })
  console.log(JSON.stringify(r, null, 2))
  return false

})();
