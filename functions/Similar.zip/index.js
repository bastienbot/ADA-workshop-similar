const superagent = require('superagent');

const Similar = {

  getSimilars: async ({ query }) => {
    try {
      const res = await superagent
        .get("https://tastedive.com/api/similar")
        .query({
          q: query,
          info: 1
      });
      console.log(res.body.Similar.Results.length)
      if (res.body.Similar.Results && res.body.Similar.Results.length > 0) {
        return res.body.Similar.Results.map(r => {
          r.youtube = `https://www.youtube.com/watch?v=${r.yID}`
          return {
            name: r.Name,
            type: r.Type,
            teaser: r.wTeaser,
            wiki: r.wUrl,
            youtube: `https://www.youtube.com/watch?v=${r.yID}`
          };
        })
      } else {
        return []
      }
    } catch (err) {
      console.log(err)
      throw err
    }
  },

};

exports.handler = async function handler(event) {
  if (!event.query) return []
  return  Similar.getSimilars(event)
};
(async function () {

  const r = await Similar.getSimilars({ query: "Coldplay" })
  console.log(JSON.stringify(r, null, 2))

})();